import javax.swing.*;
import PackageTwo.GuestRegistrationPanel;
import PackageFive.RoomBookingPanel;
import PackageFour.InventoryManagementPanel;
import PackageThree.HotelInfoPanel;
import PackageOne.ActionsPanel;

public class Hotel extends JFrame {
    public Hotel() {
        setTitle("Hotel Management");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Register a Guest:", new GuestRegistrationPanel());
        tabbedPane.addTab("Book a room:", new RoomBookingPanel());
        tabbedPane.addTab("Inventory Management", new InventoryManagementPanel());
        tabbedPane.addTab("Hotel Info", new HotelInfoPanel());
        tabbedPane.addTab("Actions", new ActionsPanel());

        add(tabbedPane);
    }

    public static void main(String[] args) {
        Hotel hotel = new Hotel();
        hotel.setVisible(true);
    }
}
