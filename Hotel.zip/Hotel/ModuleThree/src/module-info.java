module ModuleThree {
    requires java.desktop;
    exports PackageThree;
}