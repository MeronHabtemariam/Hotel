package PackageThree;

import javax.swing.*;
import java.awt.*;

public class HotelInfoPanel extends JPanel {
    public HotelInfoPanel() {
        setLayout(new BorderLayout());

        JTextArea infoArea = new JTextArea("Welcome to the Hotel Management System!\n\n"
                + "This application helps manage guests, room bookings, and inventory efficiently.");


        add(new JScrollPane(infoArea), BorderLayout.CENTER);
    }
}
