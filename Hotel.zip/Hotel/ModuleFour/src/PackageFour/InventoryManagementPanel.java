package PackageFour;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class InventoryManagementPanel extends JPanel {
    public InventoryManagementPanel() {
        setLayout(new BorderLayout());

        String[] columns = {"Item ID", "Item Name"};
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0);
        JTable table = new JTable(tableModel);
        JButton addRowButton = new JButton("Add Inventory Item");

        addRowButton.addActionListener(e ->
                tableModel.addRow(new Object[]{tableModel.getRowCount() + 1, "Item " + (tableModel.getRowCount() + 1)})
        );

        add(new JScrollPane(table), BorderLayout.CENTER);
        add(addRowButton, BorderLayout.SOUTH);
    }
}
