module ModuleTwo {
    requires java.desktop;
    exports PackageTwo;
}