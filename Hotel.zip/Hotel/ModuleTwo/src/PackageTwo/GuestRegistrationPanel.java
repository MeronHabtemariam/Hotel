package PackageTwo;

import javax.swing.*;
import java.awt.*;

public class GuestRegistrationPanel extends JPanel {
    public GuestRegistrationPanel() {
        setLayout(new GridLayout(4, 2));

        JLabel nameLabel = new JLabel("Guest Name:");
        JTextField nameField = new JTextField();
        JLabel contactLabel = new JLabel("Contact:");
        JTextField contactField = new JTextField();
        JButton submitButton = new JButton("Register Guest");

        submitButton.addActionListener(e -> {
            String name = nameField.getText();
            String contact = contactField.getText();
            JOptionPane.showMessageDialog(this, "Guest Registered:\nName: " + name + "\nContact: " + contact);
        });

        add(nameLabel);
        add(nameField);
        add(contactLabel);
        add(contactField);
        add(submitButton);
    }
}
