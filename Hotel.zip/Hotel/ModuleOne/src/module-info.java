module ModuleOne {
    requires java.desktop;
    exports PackageOne;
}