package PackageOne;

import javax.swing.*;

public class ActionsPanel extends JPanel {
    public ActionsPanel() {
        JButton showMessageButton = new JButton("Show Hotel Summary");

        showMessageButton.addActionListener(e ->
                JOptionPane.showMessageDialog(this, "Hotel Operations Running Smoothly!")
        );

        add(showMessageButton);
    }
}
