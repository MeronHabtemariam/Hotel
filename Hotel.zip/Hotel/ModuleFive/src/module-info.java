module ModuleFive {
    requires java.desktop;
    exports PackageFive;
}