package PackageFive;

import javax.swing.*;
import java.awt.*;

public class RoomBookingPanel extends JPanel {
    public RoomBookingPanel() {
        setLayout(new BorderLayout());

        DefaultListModel<String> listModel = new DefaultListModel<>();
        JList<String> bookingList = new JList<>(listModel);
        JButton addButton = new JButton("Book Room");
        JButton clearButton = new JButton("Clear Bookings");

        addButton.addActionListener(e -> listModel.addElement("Room " + (listModel.getSize() + 1) + " booked"));
        clearButton.addActionListener(e -> listModel.clear());

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(clearButton);

        add(new JScrollPane(bookingList), BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
}
